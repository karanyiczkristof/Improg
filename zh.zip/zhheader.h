#ifndef ZHHEADER_H
#define ZHHEADER_H


int strhossz(char*);

void konzolrolir();

void fajlbolkiir(char*);






#endif